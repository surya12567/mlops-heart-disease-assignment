Dataset is downloaded by `python -m src.data --download`. Do not commit the dataset unless permitted by your course/data terms.
