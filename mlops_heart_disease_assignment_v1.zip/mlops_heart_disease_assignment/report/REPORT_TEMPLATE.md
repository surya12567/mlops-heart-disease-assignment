# End-to-End MLOps for Heart Disease Classification
**Course:** AIMLCZG523 — MLOps Assignment 01  
**Student name / ID:** [Fill in]  
**Date:** [Fill in]  
**Repository URL:** [Add your actual repository URL]

> Replace every bracketed prompt with your own measured results, reasoning, screenshots, and observations. Do not claim a deployment or score you have not verified.

## 1. Abstract
[Summarize the problem, dataset, models, tracking, API, automation, deployment environment, and actual results in 150–200 words.]

## 2. Problem statement and objectives
[Explain binary classification and why reproducibility, deployment, CI/CD, and monitoring matter. State that this educational model must not be used for medical decisions.]

## 3. Dataset and acquisition
- Source: UCI Machine Learning Repository, Heart Disease dataset (dataset ID 45).
- Download method: `python -m src.data --download`.
- Dataset dimensions: [Use reports/eda_summary.json.]
- Target transformation: original target 0 → no disease; values greater than 0 → disease present.
- Data caveats / provenance: [Document any dataset/version issues you observe and cite the UCI source.]

## 4. Exploratory data analysis
Insert your actual figures:
- Class balance: `reports/figures/class_balance.png`
- Correlation heatmap: `reports/figures/correlation_heatmap.png`
- Feature distributions: selected `hist_*.png` files
Discuss target balance, missing values, ranges, correlations, possible data quality issues, and what you learned. Avoid causal claims from correlations.

## 5. Feature engineering and preprocessing
[Describe numeric conversion, median imputation, standard scaling, and why preprocessing is kept inside a scikit-learn Pipeline to avoid train/test leakage. Confirm whether the data contains missing values in your run.]

## 6. Model development and selection
Models:
1. Logistic Regression (balanced class weights, max iterations 2000).
2. Random Forest (300 trees, balanced class weights); a small grid search evaluates depth and minimum leaf size.

[Explain the 80/20 stratified holdout, 5-fold stratified CV on training data, random seed 42, and selection by mean CV ROC-AUC. Report actual results from `reports/cv_results.json`.]

### Results
| Model | CV ROC-AUC | Test accuracy | Test precision | Test recall | Test ROC-AUC |
|---|---:|---:|---:|---:|---:|
| Logistic Regression | [actual] | [actual] | [actual] | [actual] | [actual] |
| Random Forest | [actual] | [actual] | [actual] | [actual] | [actual] |

[Discuss trade-offs, confusion matrix, ROC curve, and limitations. Do not fill with invented values.]

## 7. Experiment tracking with MLflow
[Insert a screenshot of the MLflow UI showing both runs. Explain which parameters, CV/test metrics, model artifact, and JSON metrics artifacts were logged. Include how to launch the UI.]

## 8. Packaging and reproducibility
[Describe requirements.txt, fixed random seed, saved joblib pipeline, metadata feature list, and exact commands to reproduce training. Mention that joblib artifacts should only be loaded from trusted sources.]

## 9. API design
Endpoints:
- `GET /health`
- `POST /predict`
- `GET /metrics`

[Insert Swagger UI and successful prediction screenshots. Explain JSON schema, probability response, input validation, logs, and the medical-use disclaimer.]

## 10. CI/CD and automated testing
[Insert GitHub Actions screenshots showing lint, tests, training, and artifact upload. Describe test coverage and how failures stop the workflow. Include actual pytest output.]

## 11. Containerization and deployment
[Describe Docker build/run commands. State whether you used Minikube, Docker Desktop Kubernetes, or a public cloud. Insert build logs, `kubectl get pods,svc`, and verified API response screenshots. Include actual deployed URL only if publicly accessible and tested.]

## 12. Monitoring and logging
[Explain request counter and latency histogram exposed on `/metrics`, request logs, health endpoint, and what additional production monitoring/alerting you would add. Insert `/metrics` screenshot.]

## 13. Architecture
```text
UCI Dataset
    |
Download + validation -> EDA / plots
    |
Preprocessing + CV + model comparison
    |                 \
MLflow tracking       Evaluation reports
    |
Serialized pipeline + metadata
    |
FastAPI (/predict, /health, /metrics)
    |
Docker image -> Kubernetes Service -> Client
    |
GitHub Actions: lint -> tests -> data -> EDA -> train -> artifacts
```

[Replace or redraw this diagram if your implementation differs.]

## 14. Limitations, ethics, and future improvements
[Discuss small/older dataset, possible population bias, data quality, lack of external validation, probability calibration, drift monitoring, privacy, security, authentication, rate limiting, and why predictions are not medical advice.]

## 15. Conclusion
[Summarize what you implemented and learned, based on evidence you collected.]

## References
1. UCI Machine Learning Repository, Heart Disease dataset: https://archive.ics.uci.edu/dataset/45/heart+disease
2. Scikit-learn documentation: https://scikit-learn.org/stable/
3. MLflow documentation: https://mlflow.org/docs/latest/
4. FastAPI documentation: https://fastapi.tiangolo.com/
5. Docker documentation: https://docs.docker.com/
6. Kubernetes documentation: https://kubernetes.io/docs/
7. GitHub Actions documentation: https://docs.github.com/actions
